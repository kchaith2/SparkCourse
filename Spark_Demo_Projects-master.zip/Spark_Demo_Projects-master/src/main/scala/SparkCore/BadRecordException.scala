package SparkCore

/**
  * Created by Pankaj Gaur on 10-07-2020.
  */
class BadRecordException extends  Exception{

}
